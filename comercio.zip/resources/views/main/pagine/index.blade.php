@extends('layouts.app')

@section('content')



        <div class="content space">
       

            <h2 >Bienvenido<br></h2>
            <img src="images/cotillon.png" alt="400px" width="450px" align="left">
            
            
        </div>


 

@endsection
