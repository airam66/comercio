<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<p>Nombre del contacto: {{$name}}</p>
	<p>Email del contacto: {{$email}}</p>
	<p>Asunto: {{$subject}}</p>
	<p>Mensaje</p>
	{{$message}}


</body>
</html>