<?php

namespace Tests\Browser;

use Tests\DuskTestCase;
use Laravel\Dusk\Browser;
use Laravel\Dusk\Chrome;
use Illuminate\Foundation\Testing\DatabaseMigrations;

class ExampleTest extends DuskTestCase
{
    
    public function testBasicExample()
    {
        $this->browse(function (Browser $browser) {
            $browser->visitRoute('index')
                    ->assertSee('Cotillon Crea Tu');
        });
    }
}
