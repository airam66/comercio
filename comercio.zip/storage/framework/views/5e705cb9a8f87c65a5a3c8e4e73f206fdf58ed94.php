   
<?php $__env->startSection('content'); ?> 
    
    
 <div class="content-wrap centering">
      <div class="mi_letter text-center">
                  <h1>Nuestros productos</h1>
                  <img src="<?php echo e(asset('images/line.png')); ?>" alt=""> 
      </div>
                     
       <div class="row">  
          <div class="col-md-3">
             <?php echo $__env->make('main.pagine.Catalogo.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           
           </div> 

          <div class="col-md-9">
               
             <div >   
            <!-- works -->

           
           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="card product"style="width: 300px;height: 300px;margin-right:10px; margin-bottom:8px;margin-left: 10px;color:gray">
                 
                  <div  style="background:url(<?php echo e(asset('images/categories/'.$category->extension)); ?>); height:100%;background-size: 300px 300px; " class="text-center">
                  <a href="<?php echo e(route('searchEventCategory', [$category->id ,  $name])); ?>">
                    <button type="button"
                    style="margin-top: 200px;"class="btn btn-success">VER
                      PRODUCTOS 
                    </button> 
                    </a>
                  </div>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
       </div>
              
          </div> 
          <div class="text-center">
           
          </div>
        </div>  

        <div class="text-center">
        <img src="<?php echo e(asset('images/line.png')); ?>" alt=""> 
        </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>