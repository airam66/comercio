<?php $__env->startSection('content'); ?>

 <section class="main" id="main">  
      <div class="banner">
          <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="<?php echo e(asset('assets/img/recuerdo.jpg')); ?>" alt="" class="">
      <div class="carousel-caption">
          <i class="fw-icon-pencil"></i>
        <h2>Corem ipsum</h2>
        <h1>sit amet vivamus</h1>
        <a href="#" class="btn"> more info</a>
      </div>
    </div>
    <div class="item">
      <img src="<?php echo e(asset('assets/img/regalos.jpg')); ?>" alt="">
      <div class="carousel-caption">
          <i class="fw-icon-pencil"></i>
        <h2>Corem ipsum</h2>
        <h1>sit amet vivamus</h1>
        <a href="#" class="btn"> more info</a>
      </div>
    </div>
    <div class="item">
      <img src="<?php echo e(asset('assets/img/2.jpg')); ?>" alt="">
      <div class="carousel-caption">
          <i class="fw-icon-pencil"></i>
        <h2>Corem ipsum</h2>
        <h1>sit amet vivamus</h1>
        <a href="#" class="btn"> more info</a>
      </div>
    </div>
  </div>

  <!-- Controls 
  <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>-->
</div>
      </div>
      <div class="content-wrap">
        <div class="heading text-center">
           <h1>Vení y lleva lo que más te guste.</h1>
        <img class="dividerline" src="<?php echo e(asset('assets/img/sep.png')); ?>" alt="">
        <h3>Tenemos diversos productos personalizados.<br> 
Hace de tu fiesta un recuerdo inolvidable.</h3>
          
      </div> 
          
        </div>
      
      </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>