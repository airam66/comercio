 
 
<?php $__env->startSection('content'); ?>
  <div class="container-fluid spark-screen">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">

        <!-- Default box -->
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Nuevo producto</h3>
           

            <div class="box-tools pull-right">
              <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Minimizar">
                <i class="fa fa-minus"></i></button>
              <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Cerrar">
                <i class="fa fa-times"></i></button>
            </div>
          </div>
          <div class="box-body">
            
          <?php echo Form::open(['route'=>'products.store', 'method'=>'POST', 'files'=>true]); ?>

            
             <?php echo Field::text('name'); ?>


              <div class= "form-group">
              <?php echo Form::label('category_id','Categoria'); ?>

              <?php echo Form::select('category_id', $categories ,null, ['class'=>'form-control', 'placeholder'=>'Seleccione una categoria']); ?> 
              </div> 

             <?php echo Field::number('code'); ?>

              
          
              <?php echo Field::file('image'); ?>

          
              
              <div class= "form-group">
              <?php echo Form::label('events','Evento'); ?>

              <?php echo Form::select('events[]', $events ,null, ['class'=>'form-control select-tag','multiple']); ?>

              </div> 

              <div class= "form-group">
              <?php echo Form::label('line_id','Linea'); ?>

              <?php echo Form::select('line_id', $lines ,null, ['class'=>'form-control','placeholder'=>'Seleccione una linea']); ?> 
              </div> 

              <div class= "form-group">
              <?php echo Form::label('brand_id','Marca'); ?>

              <?php echo Form::select('brand_id', $brands ,null, ['class'=>'form-control','placeholder'=>'Seleccione una marca']); ?> 
              </div> 

              <div class="form-group">
              <?php echo Form::label('description','Descripcion'); ?>

              <?php echo Form::text('description',"", ['class'=>'form-control']); ?>

              </div>
            
              <div class="col-md-4">
              <?php echo form::label('Precio de compra'); ?>

              
              <input class="form-control" onkeyup="this.form.wholesale_price.value=parseFloat(this.value)+this.value*<?php echo e($porcentage->wholesale_porcentage); ?>/100;this.form.retail_price.value=parseFloat(this.value)+this.value*<?php echo e($porcentage->retail_porcentage); ?>/100;" name="purchase_price" type="number" whit step="any">
              </div>
              <div class="col-md-3 col-md-offset-1">
              <?php echo Field::number('wholesale_price','<input name="wholesale_price" type="number" with step="any">', ['class'=>'form-control','step'=>'any']); ?>

              </div>
              <div class="col-md-3 col-md-offset-1">
              <?php echo Field::number('retail_price','<input name="retail_price" type="number" with step="any">', ['class'=>'form-control','step'=>'any']); ?>

              </div>


              <?php echo Field::number('stock'); ?>


              <?php echo Field::number('wholesale_cant'); ?>

            

              <div class= "form-group">
              <?php echo Form::label('status','Estado'); ?>

              <?php echo Form::select('status', ['activo'=>'activo','inactivo'=>'inactivo'],null,['class'=>'form-control']); ?> 
              </div>

              <div class="form-group">
              <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

              </div>
          
 
              <?php echo Form::close(); ?>


          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
  $('.select-tag').chosen({
    placeholder_text_multiple: "Seleccione los eventos",

  });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>