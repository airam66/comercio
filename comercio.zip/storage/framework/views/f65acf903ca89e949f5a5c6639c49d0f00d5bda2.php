 
 
<?php $__env->startSection('content'); ?>
  <div class="container-fluid spark-screen">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">

        <!-- Default box -->
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Nuevo producto</h3>
           

            <div class="box-tools pull-right">
              <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Minimizar">
                <i class="fa fa-minus"></i></button>
              <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Cerrar">
                <i class="fa fa-times"></i></button>
            </div>
          </div>
          <div class="box-body">
            
<?php echo Form::open(['route'=>'products.store', 'method'=>'POST', 'files'=>true]); ?>

            
             <?php echo Field::text('name'); ?>


              <div class= "form-group">
              <?php echo Form::label('category_id','Categoria'); ?>

              <?php echo Form::select('category_id', $categories ,null, ['class'=>'form-control']); ?> 
              </div> 

             <?php echo Field::number('code'); ?>

              
          
              <?php echo Field::file('image'); ?>

          
              
              <div class= "form-group">
              <?php echo Form::label('event_id','Evento'); ?>

              <?php echo Form::select('event_id', $events ,null, ['class'=>'form-control']); ?>

              </div> 

              <div class= "form-group">
              <?php echo Form::label('line_id','Linea'); ?>

              <?php echo Form::select('line_id', $lines ,null, ['class'=>'form-control']); ?> 
              </div> 

              <div class= "form-group">
              <?php echo Form::label('brand_id','Marca'); ?>

              <?php echo Form::select('brand_id', $brands ,null, ['class'=>'form-control']); ?> 
              </div> 

              <div class="form-group">
              <?php echo Form::label('description','Descripcion'); ?>

              <?php echo Form::text('description',null, ['class'=>'form-control']); ?>

              </div>
            
               <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <td><table width="50%" border="0" align="center" cellpadding="0" cellspacing="0">
              <?php echo form::label('Precio'); ?>

              <p><input onkeyup="this.form.wholesale_price.value=parseFloat(this.value)+this.value*<?php echo e($porcentage->wholesale_porcentage); ?>/100;this.form.retail_price.value=parseFloat(this.value)+this.value*<?php echo e($porcentage->retail_porcentage); ?>/100;" name="purchase_price" type="number" whit step="any"></p>
              </table></td>
              <td><table width="50%" border="0" align="center" cellpadding="0" cellspacing="0">
              <?php echo Form::label('Precio por Mayor'); ?>

              <p><input name="wholesale_price" type="number" with step="any"> </p>        
              </table></td>
              <td><table width="50%" border="0" align="center" cellpadding="0" cellspacing="0">
              <?php echo Form::label('Precio por menor'); ?>

              <p><input name="retail_price" type="number" with step="any"></p>
              </table></td>
               </table> 

             <?php echo Field::number('stock'); ?>


              <?php echo Field::number('wholesale_cant'); ?>

            

               <div class= "form-group">
  
              <?php echo Form::label('status','Estado'); ?>

              <?php echo Form::select('status', ['active'=>'activo','inactive'=>'inactivo'],null,['class'=>'form-control']); ?> 
              </div>

              <div class="form-group">
              <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

              </div>
          
 
              <?php echo Form::close(); ?>


          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>