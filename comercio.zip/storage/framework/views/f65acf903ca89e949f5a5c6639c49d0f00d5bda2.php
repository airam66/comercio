 
 
<?php $__env->startSection('content'); ?>
  <div class="container-fluid spark-screen">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">

        <!-- Default box -->
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Nuevo producto</h3>
          
          </div>
          <div class="box-body">
            
          <?php echo Form::open(['route'=>'products.store', 'method'=>'POST', 'files'=>true]); ?>

            
              <?php echo Field::text('name'); ?>


              <?php echo Field::select('category_id', $categories, ['class'=>'select-category','empty'=>'Seleccione una categoria']); ?> 
       

              <?php echo Field::number('code'); ?>

              
          
              <?php echo Field::file('image'); ?>

          
              
              <div class= "form-group">
              <?php echo Form::label('events','Evento'); ?>

              <?php echo Form::select('events[]', $events ,null, ['class'=>'form-control select-tag','multiple']); ?>

              </div> 

              <?php echo Field::select('line_id', $lines ,['class'=>'select-lines','empty'=>'Seleccione una linea']); ?> 

              <?php echo Field::select('brand_id', $brands, ['class'=>'select-brands','empty'=>'Seleccione una marca']); ?> 
          

              <div class="form-group">
              <?php echo Field::text('description',null, ['class'=>'form-control']); ?>

              </div>
              
              <div class="controls col-md-4">
             <?php echo Field::number('purchase_price',null, ['class'=>'form-control','step'=>'any']); ?>

             </div>

              <div class="col-md-3 col-md-offset-1">
              <?php echo Field::number('retail_price',null, ['class'=>'form-control','step'=>'any']); ?>

              </div>
              <div class="col-md-3 col-md-offset-1">
              <?php echo Field::number('wholesale_price',null, ['class'=>'form-control','step'=>'any']); ?>

              </div>


              <?php echo Field::number('stock'); ?>


              <?php echo Field::number('wholesale_cant'); ?>

            

              <div class= "form-group">
              <?php echo Form::label('status','Estado'); ?>

              <?php echo Form::select('status', ['activo'=>'activo','inactivo'=>'inactivo'],null,['class'=>'form-control']); ?> 
              </div>
              <?php echo Form::hidden('route',$route); ?>

              <div class="form-group">
              <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

              </div>
              
 
              <?php echo Form::close(); ?>


          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
  $('.select-tag').chosen({
    placeholder_text_multiple: "Seleccione los eventos",
  });
  $('.select-category').chosen();
  $('.select-brands').chosen();
  $('.select-lines').chosen();

</script>
<script >
  $('#purchase_price').on('keyup', function(){
    $('#wholesale_price').val(parseFloat(this.value)+this.value*<?php echo e($porcentage->wholesale_porcentage); ?>/100);
    $('#retail_price').val(parseFloat(this.value)+this.value*<?php echo e($porcentage->retail_porcentage); ?>/100);
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>