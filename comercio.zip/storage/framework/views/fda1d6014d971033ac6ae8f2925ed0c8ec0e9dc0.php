<?php $__env->startSection('content'); ?>

<div class="box box-primary">

<div class="box-header ">
<h2 class="box-title col-md-5">Categorias Encontradas</h2>
    
                   <!-- search name form -->
     
        <form route='admin.categories.index'  method="GET" class="col-md-3 col-md-offset-4 ">
            <div class="input-group">
              <input type="text" name="name" class="form-control" placeholder="Nombre..."> 
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
        </form>
          <!-- /.search form -->

</div>
<div class="box-body">              

 <table id="tabla table-striped" class="display table table-hover" cellspacing="0" width="100%">
       
        <thead>
            <tr>
                <th style="width:10px">Codigo</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Estado</th>
                <th>Imagen</th> 
                <th>Acción</th>
            </tr>
        </thead>
     
       
<tbody>
   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

          <?php if($category->status!='inactivo'): ?>
            <tr role="row" class="odd">
          <?php else: ?>
            <tr role="row" class="odd" style="background-color: rgb(255,96,96);">
          <?php endif; ?>
            <td><?php echo e($category->id); ?></td>
            <td><?php echo e($category->name); ?></td>
            <td><?php echo e($category->description); ?></td>
            <td><?php echo e($category->status); ?></td>

            <td> 
            <?php if($category->extension!=null): ?>
                   <div>
                   <img src="<?php echo e(asset('images/categories/'.$category->extension)); ?>" width="40" height="40"> 
                   </div>
            <?php endif; ?>
            </td>
            <td>
            <?php if($category->status!='inactivo'): ?>
             
                <a href="<?php echo e(route('categories.edit',$category->id)); ?>"  >
                        <button type="submit" class="btn btn-warning">
                            <span class="glyphicon glyphicon-pencil" aria-hidden="true" ></span>
                            
                        </button>
                     </a>

                     <a href="<?php echo e(route('categories.desable',$category->id)); ?>" onclick="return confirm('¿Seguro dara de baja esta categoria?')">
                        <button type="submit" class="btn btn-danger">
                            <span class="glyphicon glyphicon-remove-circle" aria-hidden="true" ></span>
                        </button>
                     </a>
            <?php else: ?>
                      <a href="<?php echo e(route('categories.enable',$category->id)); ?>" onclick="return confirm('¿Seguro desea dar de alta esta categoría?')">
                        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-ok" aria-hidden="true" ></span>
                        </button>
                     </a>
            <?php endif; ?>


           
        </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
    </table>




</div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>