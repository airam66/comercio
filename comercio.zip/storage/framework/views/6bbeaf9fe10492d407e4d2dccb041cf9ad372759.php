<?php $__env->startSection('content'); ?>

<div class="box box-primary">

<div class="box-header ">
<h2 class="box-title col-md-5">Lineas Encontradas</h2>
        
 
                   <!-- search name form -->
        <form route='admin.lines.index'  method="GET" class="col-md-3 col-md-offset-4 ">
            <div class="input-group">
              <input type="text" name="name" class="form-control" placeholder="Nombre..."> 
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
        </form>
          <!-- /.search form -->
        <input type ='button' class="btn btn-success"  value = 'Agregar' onclick="location.href = '<?php echo e(route('lines.create')); ?>'"/>

</div>
<div class="box-body">              

 <table id="tabla table-striped" class="display table table-hover" cellspacing="0" width="100%">
       
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Estado</th>
                <th></th>
                   
            </tr>
        </thead>
     
       
<tbody>
   <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

          <?php if($line->status!='inactivo'): ?>
            <tr role="row" class="odd">
                <td><?php echo e($line->name); ?></td>
                <td><?php echo e($line->status); ?></td>
                <td>
                <a href="<?php echo e(route('lines.desable',$line->id)); ?>" onclick="return confirm('¿Seguro dará de baja esta línea?')">
                <button type="submit" class="btn btn-danger">
                  <span class="glyphicon glyphicon-remove-circle" aria-hidden="true" ></span>
                </button>
                </a>

                  <a href="<?php echo e(route('lines.edit',$line->id)); ?>"  >
                        <button type="submit" class="btn btn-warning">
                            <span class="glyphicon glyphicon-pencil" aria-hidden="true" ></span>
                            
                        </button>
                     </a>
                </td>
              </tr>
          <?php endif; ?>
          
           
      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
    </table>




</div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>