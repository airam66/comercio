   
<?php $__env->startSection('content'); ?> 
    
    
 <div class="content-wrap centering">
      <div class="mi_letter text-center">
                  <h1>Nuestros productos</h1>
                  <img src="<?php echo e(asset('images/line.png')); ?>" alt=""> 
      </div>
                     
       <div class="row">  
          <div class="col-md-3">
             <?php echo $__env->make('main.pagine.Catalogo.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           
           </div> 

          <div class="col-md-9">
               

              <div>
                <?php if(empty($products)): ?>
                   <p>No hay datos para mostrar</p>
                <?php else: ?>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="card product mystyle">
                     <div>
                       <?php if($product->extension!=null): ?>
             
                          <img src="<?php echo e(asset('images/products/'.$product->extension)); ?>"  width="160" height="150" >
            
                       <?php endif; ?>
                      </div>
                    <div >
                       <h4 class="text-center" style="height: 30px;"><?php echo e($product->name); ?></h4>
                          <div class="text-right" >
                            <!--href="<?php echo e(route('catalogueShow.show', $product->id )); ?>"-->
                            <a  href="<?php echo e(route('catalogueShow.show', $product->id )); ?>" >
                               <img src="<?php echo e(asset('images/informacion3.png ')); ?>" width="45" height="45"  > 
                            </a>
                          </div>
                    </div>
                   </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endif; ?>
             </div>
          </div> 
          <div class="text-center">
           <?php echo $products->links(); ?> 
          </div>
        </div>  

        <div class="text-center">
        <img src="<?php echo e(asset('images/line.png')); ?>" alt=""> 
        </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>