 
 
<?php $__env->startSection('content'); ?>
  <div class="container-fluid spark-screen">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">

        <!-- Default box -->
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Nuevo cliente</h3>
          </div>
          <div class="box-body">
            
          <?php echo Form::open(['route'=>'clients.store', 'method'=>'POST', 'files'=>true]); ?>

            
              <?php echo Field::text('name'); ?>


              <?php echo Field::text('cuil'); ?>

              <div class="col-md-6">
              <?php echo Field::text('address'); ?>

              </div>
              <div class="col-md-6">
              <?php echo Field:: text('location'); ?>

              </div>
              <div class="col-md-6">
              <?php echo Field::text('email'); ?>

              </div>
              <div class="col-md-6">
              <?php echo Field::number('phone'); ?>

              </div>
              <?php echo Form::hidden('bill',0); ?>

              
              <div class= "form-group">
              <?php echo Form::label('status','Estado'); ?>

              <?php echo Form::select('status', ['activo'=>'activo','inactivo'=>'inactivo'],null,['class'=>'form-control']); ?> 
              </div>

              <div class="form-group">
              <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

              </div>
          
 
              <?php echo Form::close(); ?>


          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script >
  $('#cuil').on('keypress', function(e){

    tecla = (document.all) ? e.keyCode : e.which;

    //Tecla de retroceso para borrar, siempre la permite
    if (tecla==8){
        return true;
    }
        
    // Patron de entrada, en este caso solo acepta numeros
    patron =/[0-9]/;
    tecla_final = String.fromCharCode(tecla);
    return patron.test(tecla_final);

  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>