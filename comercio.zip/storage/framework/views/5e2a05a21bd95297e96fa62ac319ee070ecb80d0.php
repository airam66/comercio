<?php $__env->startSection('content'); ?>

<div class="box box-primary">

<div class="box-header">
                  <h3 class="box-title">Productos Encontrados</h3>
                </div>

<div class="box-body">              

 <table id="tabla table-striped" class="display table table-hover" cellspacing="0" width="100%">
       
        <thead>
            <tr>
             <th style="width:10px">Codigo</th>
                <th>Nombre</th>
                <th>Categoria</th>
                <th>Estado</th>
                <th>Imagen</th>
                <th>Acción</th>
                   
            </tr>
        </thead>
 
        
       
<tbody>




   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 


         <tr role="row" class="odd">
            <td class="sorting_1"><?php echo e($product->code); ?></td>
            
           
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->category->name); ?></td>
            <td><?php echo e($product->status); ?></td>

            <td> 
            <?php if($product->extension!=null): ?>
                    <div>
                    <img src="<?php echo e(asset('images/products/'.$product->extension)); ?>" width="40" height="40" >
                    </div>
            <?php endif; ?>
            </td>

            <td> 
                <a href="<?php echo e(route('products.edit',$product->id)); ?>"  >
                        <button type="submit" class="btn btn-warning">
                            <span class="glyphicon glyphicon-pencil" aria-hidden="true" ></span>
                            
                        </button>
                     </a>
            </td>

            <td></td>
           
        </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
    </table>


</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>