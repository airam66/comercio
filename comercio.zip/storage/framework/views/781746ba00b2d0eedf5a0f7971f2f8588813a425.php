<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Datos de Cotillon</div>
                <div class="panel-body">

   <?php echo Form::open(['route'=>'cotillon.store', 'method'=>'POST']); ?>


   <div class="form-group">

      <?php echo Form::label('name','Nombre'); ?>

      <?php echo Form::text('name',null, ['class'=>'form-control','placeholder'=>'Nombre del cotillon']); ?>

   </div>


   <div class="form-group">

      <?php echo Form::label('description_AboutUs','Descripcion'); ?>

      <?php echo Form::textarea('description_AboutUs',null, ['class'=>'form-control']); ?>

   </div>

    <div class="form-group">

      <?php echo Form::label('address','Direccion'); ?>

      <?php echo Form::text('address',null, ['class'=>'form-control']); ?>

   </div>

   <div class="form-group">

      <?php echo Form::label('phones','Telefono/s'); ?>

      <?php echo Form::text('phones',null, ['class'=>'form-control']); ?>


   </div>

   <div class="form-group">

      <?php echo Form::label('email','Email'); ?>

      <?php echo Form::email('email',null, ['class'=>'form-control']); ?>

   </div>

    <div class="form-group">

      <?php echo Form::label('facebook','Facebook'); ?>

      <?php echo Form::text('facebook',null, ['class'=>'form-control']); ?>

   </div>

    <div class="form-group"> 

      <?php echo Form::label('business_hours','Horarios de Atencion'); ?>

      <?php echo Form::text('business_hours',null, ['class'=>'form-control']); ?>

   </div>

   <div class="form-group">
   <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

   </div>
  
 
   <?php echo Form::close(); ?>


     </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>