<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Reporte de stock</title>
    <link rel="stylesheet" href="<?php echo e('css/pdf.css'); ?>" media="all" />
  </head>
  <body >
    <header class="clearfix">
      <div id="logo">
        <img src="<?php echo e(asset('images/cotillon.png ')); ?>" >
      </div>
      <h1>LISTADO DE PRODUCTOS CON BAJO STOCK</h1>
      
    </header>
      

      <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <h2>Proveedor: <?php echo e($provider->provider_name); ?></h2>
        
         
            <main>
             <table>
              <thead>
               <tr>
                <th>Productos</th>
                <th>Marca</th>
                <th>Stock</th>
                </tr>
                </thead> 
                 <tbody>
                 
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($provider->provider_id == $product->provider_id): ?>
                  
                            <tr>
                            <td class="text-center"><?php echo e($product->product_name); ?></td>
                            <td class="text-center"><?php echo e($product->brand_name); ?></td>
                            <td class="text-center"><?php echo e($product->stock); ?></td>
                            </tr>
                        <?php endif; ?>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
         
                </tbody>

             </table> 
            </main>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

    <footer>
     
    </footer>
    
  </body>
</html>