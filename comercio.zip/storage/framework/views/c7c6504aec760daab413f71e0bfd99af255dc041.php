
<div class="panel panel-success">
   <div class="panel-heading" >
             Eventos
   </div>
   <div class="panel-body">

          <ul class="list-group">
           <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     
          <li class="list-group-item"  > 
          <a href="<?php echo e(route('searchEvent',$event->name)); ?>">
             <div style="color: black;"><?php echo e($event->name); ?></div>  
          </a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul> 
            
 </div>
       
</div>