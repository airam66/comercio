 
 
<?php $__env->startSection('content'); ?>
  <div class="container-fluid spark-screen">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">

        <!-- Default box -->
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Nueva categoria</h3>
           

            <div class="box-tools pull-right">
              <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Minimizar">
                <i class="fa fa-minus"></i></button>
              <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Cerrar">
                <i class="fa fa-times"></i></button>
            </div>
          </div>
          <div class="box-body">
            
            <?php echo Form::open(['route'=>'categories.store', 'method'=>'POST','files'=>true]); ?>


             <div class="form-group">
              <?php echo Field::text('name',null, ['class'=>'form-control']); ?>

             </div>


              <div class="form-group">

              <?php echo Form::label('description','Descripcion'); ?>

              <?php echo Form::text('description'," ", ['class'=>'form-control']); ?>

              </div>
              
              <?php echo Field::file('image'); ?>

            
              <div class= "form-group">
  
              <?php echo Form::label('status','Estado'); ?>

              <?php echo Form::select('status', ['activo'=>'activo','inactivo'=>'inactivo'],null,['class'=>'form-control']); ?> 
              </div>
              <div class="form-group">
              <?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

              </div>
          
 
              <?php echo Form::close(); ?>


          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>