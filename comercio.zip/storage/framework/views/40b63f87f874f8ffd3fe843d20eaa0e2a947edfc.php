<?php $__env->startSection('content'); ?>
<div class="container space">
 <div class="row">
 <div class="col-md-3">
        <?php echo $__env->make('main.pagine.Catalogo.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           
  </div>
<!-- -->
  <div class="col-md-9 text-center">
	
	   
		<div class="card product text-left" >
		   
          
			<h1> <?php echo e($product->name); ?> </h1>
			<div class="row">
				<div class="col-sm-6 col-xs-12">

					<img src="<?php echo e(asset('images/products/'.$product->extension)); ?>" width="100%" height="300">

				</div>
				<div class="col-sm-6 col-xs-12 text-center">
				<p >
					<b>Descripción</b>

				</p>
				<p >
					<?php echo e($product->description); ?>

				</p>
				<p>
					<b>Marca: </b> <?php echo e($product->brand->name); ?>

				</p>
				</div>
			</div>
		</div>
     

     </div>
     </div>
     </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>