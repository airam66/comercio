   
<?php $__env->startSection('content'); ?> 

<div class="content-wrap centering">
      <div class="mi_letter text-center">
                  <h1>Nuestros productos</h1>
                  <img src="<?php echo e(asset('images/line.png')); ?>" alt=""> 
      </div>
                     
       <div class="row">  
          <div class="col-md-3">
             <?php echo $__env->make('main.pagine.Catalogo.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           
           </div> 

          <div class="col-md-9">
               
             <div >   
            <!-- works -->

           
           <div class="content-wrap centering">
	   
		<div class="card product-show text-left" >
		   
          
			<h1> <?php echo e($product->name); ?> </h1>
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<img src="<?php echo e(asset('images/products/'.$product->extension)); ?>" width="300" height="300">
				</div>
				<div class="col-sm-6 col-xs-12 text-center">
				<p >
					<strong>Descripción</strong>

				</p>
				<p >
					<?php echo e($product->description); ?>

				</p>
				<p><b> Marca:</b><?php echo e($product->brand->name); ?></p>
				
				</div>
			</div>
		</div>
     </div>
      
       </div>
              
          </div> 
          <div class="text-center">
           
          </div>
        </div>  

        <div class="text-center">
        <img src="<?php echo e(asset('images/line.png')); ?>" alt=""> 
        </div>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>