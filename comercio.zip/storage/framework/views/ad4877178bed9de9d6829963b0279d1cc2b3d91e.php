 
 
<?php $__env->startSection('content'); ?>
  <div class="container-fluid spark-screen">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">

        <!-- Default box -->
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Editar Linea</h3>
          </div>
          <div class="box-body">
            
           <?php echo Form::model($line,['route'=>['lines.update',$line->id], 'method'=>'PATCH', 'files'=>true]); ?>


             <div class="form-group">
              <?php echo Field::text('name',null, ['class'=>'form-control']); ?>

             </div>


              <div class= "form-group">
  
              <?php echo Form::label('status','Estado'); ?>

              <?php echo Form::select('status', ['activo'=>'activo','inactivo'=>'inactivo'],null,['class'=>'form-control']); ?> 
              </div>

              <div class="form-group">
              <?php echo Form::submit('Guardar',['class'=>'btn btn-primary']); ?>

              </div>
          
 
              <?php echo Form::close(); ?>


          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>