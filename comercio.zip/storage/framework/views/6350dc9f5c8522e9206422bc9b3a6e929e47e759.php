<?php $__env->startSection('content'); ?>

<div class="box box-primary">

     <div class="box-header ">
        <h2 class="box-title col-md-5">Proveedores Encontrados</h2>    
        
        <!-- campo de busqueda-->
        <form route='admin.providers.index'  method="GET" class="col-md-3 col-md-offset-4 ">
            <div class="input-group">
              <input type="text" name="name" class="form-control" placeholder="Nombre..."> 
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
        </form>
          <!-- fin campo de busqueda -->
        
        <input type ='button' class="btn btn-success"  value = 'Agregar' onclick="location.href = '<?php echo e(route('providers.create')); ?>'"/> 

      </div>
     
     <div class="box-body">              

       <table id="tabla table-striped" class="display table table-hover" cellspacing="0" width="100%">
       
          <thead>
            <tr>
               
                <th>Nombre</th>
                <th>Direccion</th>
                <th>Teléfono</th>
                <th>Provincia</th> 
                <th></th>
            </tr>
          </thead>
     
       
          <tbody>
             <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

		          <?php if($provider->status!='inactivo'): ?>
		            <tr role="row" class="odd">
		          <?php else: ?>
		            <tr role="row" class="odd" style="background-color: rgb(255,96,96);">
		          <?php endif; ?>
		            
		            <td><?php echo e($provider->name); ?></td>
		            <td><?php echo e($provider->address); ?></td>
		            <td><?php echo e($provider->phone); ?></td>
		            <td><?php echo e($provider->province); ?></td>
                    <td>
                      <button type="button" class="btn btn-primary " data-toggle="modal" id="first" data-title="Detail" data-target="#favoritesModalProduct" onclick="list(<?php echo e($provider->id); ?>)">
                          <i class="fa fa-list"></i>
                      </button>
                      
                    
                     <?php if($provider->status!='inactivo'): ?>
                       <a href="<?php echo e(route('providers.edit',$provider->id)); ?>"  >
                            <button type="submit" class="btn btn-warning">
                                <span class="glyphicon glyphicon-pencil" aria-hidden="true" ></span>
                                
                            </button>
                        </a>  

                        <a href="<?php echo e(route('providers.desable',$provider->id)); ?>" onclick="return confirm('¿Seguro dará de baja este proveedor?')">
                            <button type="submit" class="btn btn-danger">
                                <span class="glyphicon glyphicon-remove-circle" aria-hidden="true" ></span>
                            </button>
                        </a> 
                    <?php else: ?>
                       <a href="<?php echo e(route('providers.enable',$provider->id)); ?>" onclick="return confirm('¿Seguro desea dar de alta este proveedor?')">
                            <button type="submit" class="btn btn-success">
                                <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
                            </button>
                         </a>

                    <?php endif; ?>
                    <?php echo $__env->make('admin.providers.providerProduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  </td>
		           
              </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<script>
function list($id){
 
  $.ajax({
    type: 'get',
    url:  "<?php echo e(URL::to('admin/listProducts')); ?>",
    data:{'provider_id':$id},
    success: function(data){
      $('#mostrar').html(data);
    }
    
  })
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>