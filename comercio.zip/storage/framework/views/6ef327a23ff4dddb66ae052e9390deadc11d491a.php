<?php $__env->startSection('content'); ?>

<div class="container-fluid spark-screen">
    <div class="row">
      <div class="col-md-12">

        <!-- Default box -->
      <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Actualizar stock de productos personalizados</h3>
         </div>
        <div class="box-body">
          <?php echo Form::open(['route'=>'products.updateStock', 'method'=>'POST']); ?>

          <section>
              <div class="panel-body borde"><!--busqueda producto-->
                <h3>Producto</h3>
                <div class="row " >
                    <div class="col-md-3 pull-left" >
                         <?php echo Field::text('code'); ?>

                                                  
                    </div> 
                    <div class="pull-left">
                    <br>
                       <button id="iconSearch" type="button" class="btn btn-primary pull-left" data-toggle="modal" id="first" data-title="Buscar" data-target="#favoritesModalProduct">
                          <i class="fa fa-search"></i>
                       </button>
                   </div>
              
                   <div class="col-md-2 col-md-offset-2">
                        <?php echo Field::number('amount'); ?>

                        
                    </div>                    
                </div>

                 <div class="row " >
                    <div class="col-md-4 pull-left ">
                         <?php echo Field::text('name',null,['disabled']); ?>

                    </div>
                     
                    <div class="col-md-4  col-md-offset-1 ">
                         <?php echo Field::text('stock',null,['disabled']); ?>

                    </div>

                 </div>

                  <div class="form-group">
                   <input type="hidden" name="id" id="id">
                 </div>

                 <div class="form-group">
                   <?php echo Form::submit('Confirmar',['class'=>'btn btn-primary']); ?>

                 </div>
             </div>
              
              </section>
              <?php echo Form::close(); ?>

            </div>
 
          </div>
        </div>
      </div>
    </div>
<?php echo $__env->make('admin.products.searchCraftProducts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$('#search').on('keyup', function(){
  $value=$(this).val();
  $.ajax({
    type: 'get',
    url:  "<?php echo e(URL::to('admin/searchCraft')); ?>",
    data:{'search':$value},
    success: function(data){
      $('#mostrar').html(data);
    }
    
  })
})
</script>

<script>
  function SearchLetter($letter){
  $value=$letter;
  console.log($value);
  $.ajax({
    type: 'get',
    url:  "<?php echo e(URL::to('admin/searchCraftProducts')); ?>",
    data:{'searchL':$value},
    success: function(data){
      $('#mostrar').html(data);
    }
    
  });
  }
</script>

<script >
  function complete($id,$code,$name,$wholesale,$retail,$stock){
    var am=0;

    $('#stock').val($stock);
     $('#code').val($code);
    $('#id').val($id);
    $('#name').val($name);
    $('#favoritesModalProduct').modal('hide');
  };


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>