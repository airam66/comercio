 
 
 
<?php $__env->startSection('content'); ?>
  <div class="container-fluid spark-screen">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">

        <!-- Default box -->
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Invoice</h3>
           

           <div class="box-body">
                 <a href="" >
                        <button type="submit" class="btn btn-primary">
                            <span class="glyphicon glyphicon-search" aria-hidden="true" ></span>
                            
                        </button>
                     </a>


           </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </div>
    </div>
  </div>


  <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Nueva Linea</h3>
           



            <div class="box-tools pull-right">
              <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Minimizar">
                <i class="fa fa-minus"></i></button>
              <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Cerrar">
                <i class="fa fa-times"></i></button>
            </div>
          </div>
          <div class="box-body">
            
                <button type="button" class="btn btn-primary btn-lg"  data-toggle="modal" data-id="" data-title="Buscar"data-target="#favoritesModal">
                Buscar
                </button>


 <div class="modal fade" id="favoritesModal" tabindex="-1" 
      role="dialog"aria-labelledby="favoritesModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:lightgray">
             <button type="button" class="close" data-dismiss="modal" aria-label="Close">
             <span aria-hidden="true">&times;</span>
             </button>
             <h4 class="modal-title" id="favoritesModalLabel">BUSCAR PRODUCTOS</h4>
      </div>
      <div class="modal-body">
        <table id="tabla table-striped" class="display table table-hover" cellspacing="0" width="100%">
       
        <thead>
            <tr>
             <th style="width:10px">Codigo</th>
                <th>Nombre</th>
                <th>Stock</th>
                <th>Categoría</th>
               
                <th>Línea</th>
                <th>Estado</th>
                <th>Imagen</th> 
                <th>Acción</th>
                   
            </tr>
        </thead>
     
       
<tbody>
   
    </table>

      </div><!--FIN DEL BODY-->
      <div class="modal-footer">
        <button type="button" 
           class="btn btn-default" 
           data-dismiss="modal">SALIR</button>
        <span class="pull-right">
          <button type="button" class="btn btn-primary">
            AGREGAR
          </button>
        </span>
      </div>
    </div>
  </div>
</div>

          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>