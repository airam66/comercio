 
 
<?php $__env->startSection('content'); ?>
  <div class="container-fluid spark-screen">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">

        <!-- Default box -->
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Modificar categoria</h3>
           

            <div class="box-tools pull-right">
              <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Minimizar">
                <i class="fa fa-minus"></i></button>
              <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Cerrar">
                <i class="fa fa-times"></i></button>
            </div>
          </div>
          <div class="box-body">
            
            <?php echo Form::model($category,['route'=>['categories.update',$category->id], 'method'=>'PATCH', 'files'=>true]); ?>


              <div class="form-group">
              <?php echo Form::label('name','Nombre'); ?>

              <?php echo Form::text('name',$category->name, ['class'=>'form-control']); ?>

              </div>

              <div>
                   <?php echo form::label('Imagen Actual: '); ?> <img src="<?php echo e(asset('images/categories/'.$category->extension)); ?>" width="40" height="40" > 
                </div>
              <div class="form-group">
              <?php echo Form::label('image','Nueva Imagen'); ?>

              <?php echo Form::file('image'); ?>

             </div>

              <div class="form-group">
              <?php echo Form::label('description','Descripcion'); ?>

              <?php echo Form::text('description',null, ['class'=>'form-control']); ?>

              </div>
              
              <div class="form-group">
              <?php echo Form::submit('Guardar Cambios',['class'=>'btn btn-primary']); ?>

              </div>
 
              <?php echo Form::close(); ?>


          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  $('.select-tag').chosen({
   // placeholder_text_multiple: "Seleccione los eventos",

    
  });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>