<!--POPUP-->


 <div class="modal fade" id="favoritesModalProduct" tabindex="-1" 

      role="dialog" aria-labelledby="favoritesModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:lightblue">
             <button type="button" class="close" data-dismiss="modal" aria-label="Close">
             X
             </button>
             <h4 class="modal-title" id="favoritesModalLabel"><b>BUSCAR PRODUCTOS</b></h4>
      </div>
      <div class="modal-body">
<div>
 <?php echo $__env->make('partials.letter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <div class="input-group pull-right" >
  <input type="text" name="search" id="search" class="form-control"   placeholder="Nombre..."> 
  </div>
    <br>
    <br>
    <br>  
        
  <table id="tabla" class="display table table-hover" cellspacing="0" width="100%">
       
    <thead>
            <tr style="background-color:lightgray">
                
                <th>Nombre</th>
                <th>Precio Mayorista</th>
                <th>Precio Minorista</th>
                <th>Stock</th>
                <th></th>
                   
            </tr>
    </thead>
     
       
       
<tbody id="mostrar">

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr>
         
            <td><?php echo e($product->name); ?></td>
            <td>$<?php echo e($product->retail_price); ?></td>
            <td>$<?php echo e($product->wholesale_price); ?></td>   
            <td><?php echo e($product->stock); ?></td>
            <td><a onclick="complete(<?php echo e($product->id); ?>,'<?php echo e($product->code); ?>','<?php echo e($product->name); ?>',<?php echo e($product->wholesale_price); ?>,<?php echo e($product->retail_price); ?>,<?php echo e($product->stock); ?>)" type="button" class="btn btn-primary"> Agregar </a></td>

            

            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   
</tbody>
   
    </table>

      </div><!--FIN DEL BODY-->
      <div class="modal-footer">
        <button type="button" 
           class="btn btn-default" 
           data-dismiss="modal">SALIR</button>
      </div>
    </div>
  </div>
</div>
<!--FIN POPUP-->
