<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Orden de Compra</title>
    <link rel="shortcut icon" type="image/x-ico" href="<?php echo e(asset('images/logoss.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e('css/pdf.css'); ?>" media="all" />
   
  </head>
  <body >
    <header class="clearfix">
      <div id="logo">
        <img src="<?php echo e(asset('images/cotillon.png ')); ?>" >
      </div>
      <h1>Orden de compra N° <?php echo e($purchase->id); ?></h1>
      
    </header>
      
      <h2>Proveedor: <?php echo e($purchase->provider->name); ?> </h2>
  
      <p><h4>Dirección: <?php echo e($purchase->provider->address); ?> -- Localidad: <?php echo e($purchase->provider->location); ?>  --   Provincia: <?php echo e($purchase->provider->province); ?> -- Teléfono: <?php echo e($purchase->provider->phone); ?></h4></p>
       
         
            <main>
             <table>
              <thead>
               <tr>
                <th>Producto</th>
                <th>Marca</th>
                <th>Precio de Compra</th>
                <th>Cantidad</th>
                <th>Subtotal Estimado</th>
                </tr>
                </thead> 

                 <tbody>
                 
                     <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                            <tr>
                            <td class="text-center"><?php echo e($detail->product_name); ?></td>
                            <td class="text-center"><?php echo e($detail->brand_name); ?></td>
                            <td class="text-center">$<?php echo e($detail->price); ?></td>
                            <td class="text-center"><?php echo e($detail->amount); ?></td>
                            <td class="text-center">$<?php echo e($detail->subTotal); ?></td>
                            </tr>
                    

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
         
                </tbody>

             </table> 
              <div class="pull-right" >
                 <h3>Total estimado: $<?php echo e($purchase->total); ?> </h3>
              </div>
            </main>
           

    <footer>
    
    </footer>
    
  </body>
</html>