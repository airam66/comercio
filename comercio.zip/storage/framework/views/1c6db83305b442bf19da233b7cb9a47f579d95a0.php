<?php $__env->startSection('content'); ?>

 <section class="home" id="home">
      <div class="content-wrap centering">
            <div class="mi_letter text-center">
              <h1>Bienvenido</h1>
              <img src="<?php echo e(asset('images/line.png')); ?>" alt=""> 
            </div> 
            <div>
              <!--inicio carrucel-->
         
      <div class="banner">
          <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Wrapper for slides -->
  <div class="carousel-inner">
<?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      
    
    <?php if($imagen->id==1): ?>
    <div class="item active">
      <img src="<?php echo e(asset('images/carrusel/'.$imagen->extension)); ?>" alt="" class="">
      </div>
      <?php else: ?>
      <div class="item">
      <img src="<?php echo e(asset('images/carrusel/'.$imagen->extension)); ?>" alt="" class="">

      </div>
    <?php endif; ?>
   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </div>

 
  <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
      </div>
     
      
  
            <!---->
              
              <div class="content-wrap">
                <div class="heading text-center">
                   <h1>Vení y lleva lo que más te guste.</h1>
                      <h3>Tenemos diversos productos personalizados.<br> 
                     Hace de tu fiesta un recuerdo inolvidable.</h3>

            </div>
            </div>
             <div class="text-center">
               <img src="<?php echo e(asset('images/line.png')); ?>" alt=""> 
             </div>
        
      </div>
    </section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.my_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>