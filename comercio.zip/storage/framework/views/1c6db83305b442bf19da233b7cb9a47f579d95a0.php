<?php $__env->startSection('content'); ?>



        <div class="content space">
       

            <h2 >Bienvenido<br></h2>
            <img src="images/cotillon.png" alt="400px" width="450px" align="left">
            
            
        </div>


 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>