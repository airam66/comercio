<?php $__env->startSection('content'); ?>

 <section class="home" id="home">
      <div class="content-wrap centering">
            <div class="mi_letter text-center">
              <h1>Bienvenido</h1>
              <img src="<?php echo e(asset('images/line.png')); ?>" alt=""> 
            </div> 
            <div>
              <img src="<?php echo e(asset('images/regalos.jpg')); ?>">
              
              <div class="content-wrap">
                <div class="heading text-center">
                   <h1>Vení y lleva lo que más te guste.</h1>
                      <h3>Tenemos diversos productos personalizados.<br> 
                     Hace de tu fiesta un recuerdo inolvidable.</h3>

            </div>
            </div>
             <div class="text-center">
               <img src="<?php echo e(asset('images/line.png')); ?>" alt=""> 
             </div>
        
      </div>
    </section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.my_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>