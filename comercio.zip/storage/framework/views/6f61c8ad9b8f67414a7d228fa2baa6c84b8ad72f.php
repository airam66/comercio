<?php $__env->startSection('content'); ?>

<div class="box box-primary">

     <div class="box-header ">
        <h2 class="box-title col-md-5">Clientes Encontrados</h2>    
        
        <!-- campo de busqueda-->
        <form route='admin.providers.index'  method="GET" class="col-md-3 col-md-offset-4 ">
            <div class="input-group">
              <input type="text" name="name" class="form-control" placeholder="Nombre..."> 
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
        </form>
          <!-- fin campo de busqueda -->
        
        <input type ='button' class="btn btn-success"  value = 'Agregar' onclick="location.href = '<?php echo e(route('clients.create')); ?>'"/> 

      </div>
     
     <div class="box-body">              

       <table id="tabla table-striped" class="display table table-hover" cellspacing="0" width="100%">
       
          <thead>
            <tr>
               
                <th>Nombre</th>
                <th>Direccion</th>
                <th>Teléfono</th>
                
                <th></th>
            </tr>
          </thead>
     
       
          <tbody>
             <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

		          <?php if($client->status!='inactivo'): ?>
		            <tr role="row" class="odd">
		          <?php else: ?>
		            <tr role="row" class="odd" style="background-color: rgb(255,96,96);">
		          <?php endif; ?>
		            
		            <td><?php echo e($client->name); ?></td>
		            <td><?php echo e($client->address); ?></td>
		            <td><?php echo e($client->phone); ?></td>
		           
                    <td>
                      

                    </td>
		           
                    </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
        </table>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>