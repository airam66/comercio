 
 
<?php $__env->startSection('content'); ?>
  <div class="container-fluid spark-screen">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">

        <!-- Default box -->
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Modificar producto</h3>

           </div>

          

          </div>
          <div class="box-body">
            
            <?php echo Form::model($product,['route'=>['products.update',$product->id], 'method'=>'PATCH', 'files'=>true]); ?>


              <div class= "col-md-4">
              <?php echo form::label('Producto: '); ?>

              <?php echo e($product->name); ?>

              </div>

              <div class= "col-md-4">
              <?php echo form::label('Codigo: '); ?>

              <?php echo e($product->code); ?>

              </div>

              <div class= "col-md-4">
              <?php echo form::label('Categoria: '); ?>

              <?php echo e($product->category->name); ?>

              </div>

              <div>
                   <?php echo form::label('Imagen Actual: '); ?> <img src="<?php echo e(asset('images/products/'.$product->extension)); ?>" width="40" height="40" > 
              </div>

             <div class="form-group">
              <?php echo Form::label('image','Nueva Imagen'); ?>

              <?php echo Form::file('image'); ?>

             </div>
              
              <div class= "form-group">
              <?php echo Form::label('events','Evento'); ?>

              <?php echo Form::select('events[]', $events ,$productEvent, ['class'=>'form-control select-tag','multiple']); ?>

              </div> 

              <div class= "form-group">
              <?php echo Form::label('line_id','Linea'); ?>

              <?php echo Form::select('line_id', $lines ,$product->line->id, ['class'=>'form-control']); ?> 
              </div> 

              <div class= "form-group">
              <?php echo Form::label('brand_id','Marca'); ?>

              <?php echo Form::select('brand_id', $brands ,$product->brand->id, ['class'=>'form-control']); ?> 
              </div> 

              <div class="form-group">
              <?php echo Form::label('description','Descripcion'); ?>

              <?php echo Form::text('description',$product->description, ['class'=>'form-control']); ?>

              </div>

             <?php echo Field::number('stock'); ?>


              <div class="form-group">
              <?php echo Form::label('wholesale_cant','Cantidad de venta Mayorista'); ?>

              <?php echo Form::number('wholesale_cant',$product->wholesale_cant, ['class'=>'form-control']); ?>

              </div>

              <div class="form-group">
              <?php echo Form::submit('Guardar Cambios',['class'=>'btn btn-primary']); ?>

              </div>
          
 
              <?php echo Form::close(); ?>


          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  $('.select-tag').chosen({
    placeholder_text_multiple: "Seleccione los eventos",

    
  });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>