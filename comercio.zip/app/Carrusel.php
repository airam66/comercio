<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Carrusel extends Model
{
    protected $table="carrusel";

    protected $fillable= ['extension'];
}
