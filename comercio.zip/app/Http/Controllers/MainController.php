<?php

namespace App\Http\Controllers;// para que este como dentro de una carpeta

use Illuminate\Http\Request;

use App\Http\Requests;


class MainController extends Controller{
 
   public function index2(){
  return view('main.pagine.index2',[]);   //crear una vista dentro de la carpeta main q se llame home.

}


}

?>